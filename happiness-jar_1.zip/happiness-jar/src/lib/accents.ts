import type { AccentKey } from './types';

/** Maps an accent key to concrete colours for badges, borders, and glows. */
export const ACCENTS: Record<
  AccentKey,
  { hex: string; soft: string; text: string }
> = {
  rose: { hex: '#ffb3d1', soft: 'rgba(255,179,209,0.18)', text: '#b03a6b' },
  lilac: { hex: '#c5b3ff', soft: 'rgba(197,179,255,0.18)', text: '#5a47a8' },
  mint: { hex: '#a8e6cf', soft: 'rgba(168,230,207,0.18)', text: '#2f7d62' },
  peach: { hex: '#ffd3b6', soft: 'rgba(255,211,182,0.20)', text: '#a85f33' },
  sky: { hex: '#a8d8ff', soft: 'rgba(168,216,255,0.18)', text: '#2f6da8' },
  glow: { hex: '#ffd79a', soft: 'rgba(255,215,154,0.20)', text: '#a8772c' },
};
