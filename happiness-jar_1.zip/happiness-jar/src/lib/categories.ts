import type { CategoryMeta, CategoryId, MoodMeta, Mood } from './types';

/** The person this jar was made for. Change this one line to re-gift it. */
export const RECIPIENT_NAME = 'Esha';

/** Ordered category metadata — the single source of truth for labels/accents. */
export const CATEGORY_META: Record<CategoryId, CategoryMeta> = {
  'love-reason': { id: 'love-reason', label: 'One reason I love you', emoji: '❤️', accent: 'rose' },
  compliment: { id: 'compliment', label: 'Cute compliment', emoji: '🥹', accent: 'rose' },
  joke: { id: 'joke', label: 'Funny joke', emoji: '😂', accent: 'peach' },
  animal: { id: 'animal', label: 'Cute animal', emoji: '🐱', accent: 'mint' },
  song: { id: 'song', label: 'Song for you', emoji: '🎵', accent: 'lilac' },
  movie: { id: 'movie', label: 'Movie night', emoji: '🎬', accent: 'sky' },
  memory: { id: 'memory', label: 'A memory of us', emoji: '📸', accent: 'peach' },
  'love-letter': { id: 'love-letter', label: 'Love letter', emoji: '💌', accent: 'rose' },
  challenge: { id: 'challenge', label: 'Tiny challenge', emoji: '✨', accent: 'glow' },
  'self-care': { id: 'self-care', label: 'Self-care reminder', emoji: '🌸', accent: 'mint' },
  adhd: { id: 'adhd', label: 'For your beautiful brain', emoji: '🧠', accent: 'lilac' },
  'date-idea': { id: 'date-idea', label: 'Future date idea', emoji: '🎁', accent: 'sky' },
  bedtime: { id: 'bedtime', label: 'Bedtime message', emoji: '🌙', accent: 'lilac' },
  'good-morning': { id: 'good-morning', label: 'Good morning', emoji: '🌞', accent: 'glow' },
  coupon: { id: 'coupon', label: 'Coupon', emoji: '🍫', accent: 'peach' },
  kiss: { id: 'kiss', label: 'Virtual kiss', emoji: '💋', accent: 'rose' },
  hug: { id: 'hug', label: 'Virtual hug', emoji: '🤗', accent: 'peach' },
  surprise: { id: 'surprise', label: 'Random surprise', emoji: '🎲', accent: 'glow' },
};

export const CATEGORY_ORDER = Object.keys(CATEGORY_META) as CategoryId[];

/** Mood definitions. Comfort categories get a probability boost. */
export const MOOD_META: Record<Mood, MoodMeta> = {
  happy: {
    id: 'happy',
    label: 'Happy',
    emoji: '😊',
    comfort: ['joke', 'surprise', 'love-reason', 'animal'],
    soothing: false,
  },
  excited: {
    id: 'excited',
    label: 'Excited',
    emoji: '🤩',
    comfort: ['date-idea', 'challenge', 'surprise', 'song'],
    soothing: false,
  },
  anxious: {
    id: 'anxious',
    label: 'Anxious',
    emoji: '😰',
    comfort: ['self-care', 'hug', 'adhd', 'bedtime', 'love-letter'],
    soothing: true,
  },
  overthinking: {
    id: 'overthinking',
    label: 'Overthinking',
    emoji: '🌀',
    comfort: ['adhd', 'self-care', 'love-reason', 'hug'],
    soothing: true,
  },
  sad: {
    id: 'sad',
    label: 'Sad',
    emoji: '🥺',
    comfort: ['love-letter', 'hug', 'love-reason', 'self-care', 'compliment'],
    soothing: true,
  },
  tired: {
    id: 'tired',
    label: 'Tired',
    emoji: '😴',
    comfort: ['bedtime', 'self-care', 'hug', 'love-reason'],
    soothing: true,
  },
};

export const MOOD_ORDER = Object.keys(MOOD_META) as Mood[];
