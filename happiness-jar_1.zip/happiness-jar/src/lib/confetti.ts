import confetti from 'canvas-confetti';
import type { Rarity } from './types';

const PASTEL = ['#ffb3d1', '#c5b3ff', '#a8e6cf', '#ffd3b6', '#a8d8ff', '#ffd79a'];
const GOLD = ['#ffd79a', '#ffba6b', '#fff6e6', '#f7a64a'];

/** A gentle, rarity-aware confetti burst from the centre. */
export function celebrate(rarity: Rarity) {
  const base = { origin: { y: 0.55 }, disableForReducedMotion: true };
  if (rarity === 'legendary') {
    const end = Date.now() + 1400;
    const frame = () => {
      confetti({ ...base, particleCount: 5, angle: 60, spread: 70, origin: { x: 0, y: 0.6 }, colors: GOLD });
      confetti({ ...base, particleCount: 5, angle: 120, spread: 70, origin: { x: 1, y: 0.6 }, colors: GOLD });
      if (Date.now() < end) requestAnimationFrame(frame);
    };
    frame();
    return;
  }
  const counts: Record<Rarity, number> = { common: 28, uncommon: 50, rare: 90, legendary: 120 };
  confetti({
    ...base,
    particleCount: counts[rarity],
    spread: rarity === 'rare' ? 90 : 65,
    startVelocity: 32,
    scalar: 0.9,
    colors: PASTEL,
  });
}

/** A short upward heart-shaped pop, used by the heart-rain easter egg accent. */
export function heartPop() {
  const heart = confetti.shapeFromText({ text: '❤️', scalar: 2 });
  confetti({
    shapes: [heart],
    particleCount: 24,
    spread: 80,
    scalar: 2,
    origin: { y: 0.5 },
    disableForReducedMotion: true,
  });
}
