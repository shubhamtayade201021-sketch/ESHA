import type { Achievement } from './types';

/** Unlockable achievements, evaluated against live stats. */
export const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first-smile',
    title: 'First Smile',
    description: 'You opened the jar for the very first time.',
    emoji: '🌟',
    threshold: (s) => s.totalOpens >= 1,
  },
  {
    id: 'ten-surprises',
    title: '10 Surprises',
    description: 'Ten little gifts unwrapped.',
    emoji: '🎀',
    threshold: (s) => s.totalOpens >= 10,
  },
  {
    id: 'fifty-memories',
    title: '50 Memories',
    description: 'Fifty taps, fifty tiny moments.',
    emoji: '📚',
    threshold: (s) => s.totalOpens >= 50,
  },
  {
    id: 'hundred-joys',
    title: '100 Tiny Joys',
    description: 'One hundred bursts of happiness.',
    emoji: '💯',
    threshold: (s) => s.totalOpens >= 100,
  },
  {
    id: 'collector',
    title: 'Little Collector',
    description: 'Saved 25 unique notes to your collection.',
    emoji: '🗂️',
    threshold: (s) => s.uniqueNotes >= 25,
  },
  {
    id: 'sweetheart',
    title: 'Sweetheart',
    description: 'Hearted 5 favourites.',
    emoji: '💗',
    threshold: (s) => s.favorites >= 5,
  },
  {
    id: 'explorer',
    title: 'Curious Explorer',
    description: 'Seen a note from every single category.',
    emoji: '🧭',
    threshold: (s) => s.categoriesSeen >= 18,
  },
  {
    id: 'feelings',
    title: 'Feelings Welcome',
    description: 'Checked in with 4 different moods.',
    emoji: '🌈',
    threshold: (s) => s.moodsUsed >= 4,
  },
  {
    id: 'legendary',
    title: 'Legendary Discoverer',
    description: 'You found the Legendary Love Letter.',
    emoji: '👑',
    threshold: (s) => s.legendaryFound >= 1,
  },
];
