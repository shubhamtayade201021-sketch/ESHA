/** Centralized localStorage keys so nothing collides or drifts. */
export const STORAGE_KEYS = {
  saved: 'hjar:saved-notes:v1',
  prefs: 'hjar:preferences:v1',
  mood: 'hjar:mood:v1',
  achievements: 'hjar:achievements:v1',
  lastOpen: 'hjar:last-open:v1',
} as const;
