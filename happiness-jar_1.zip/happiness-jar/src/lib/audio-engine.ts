// A tiny self-contained sound engine built on the Web Audio API.
// Nothing is loaded from disk, so there are no audio files to ship, no
// copyright concerns, and it works completely offline. The ambient bed is a
// slow, warm pad; effects are short, gentle chimes.

type Sfx = 'sparkle' | 'open' | 'achievement' | 'heart' | 'pop';

const SCALE = [0, 2, 4, 7, 9, 12, 14]; // a soft major pentatonic-ish scale
const BASE = 261.63; // middle C

function midiToFreq(semitonesFromC: number): number {
  return BASE * Math.pow(2, semitonesFromC / 12);
}

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private ambientGain: GainNode | null = null;
  private ambientNodes: OscillatorNode[] = [];
  private shimmerTimer: number | null = null;
  private started = false;

  /** SFX volume independent of music. */
  sfxEnabled = true;

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    if (!this.ctx) {
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.9;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
    return this.ctx;
  }

  /** Start the ambient pad (idempotent). Must be called from a user gesture. */
  startAmbient() {
    const ctx = this.ensureContext();
    if (!ctx || !this.master || this.started) return;
    this.started = true;

    const gain = ctx.createGain();
    gain.gain.value = 0;
    gain.connect(this.master);
    this.ambientGain = gain;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 900;
    filter.Q.value = 0.6;
    filter.connect(gain);

    // Two slowly detuned oscillators form the pad.
    const chord = [0, 7]; // root + fifth
    chord.forEach((semi, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = midiToFreq(semi - 12);
      osc.detune.value = i === 0 ? -4 : 5;
      const oGain = ctx.createGain();
      oGain.gain.value = 0.5;
      osc.connect(oGain).connect(filter);
      osc.start();
      this.ambientNodes.push(osc);
    });

    // Slow swell so it breathes.
    const now = ctx.currentTime;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.06, now + 4);

    // Occasional shimmer bells.
    const shimmer = () => {
      this.playBell(midiToFreq(SCALE[Math.floor(Math.random() * SCALE.length)] + 12), 0.03, 2.5);
      this.shimmerTimer = window.setTimeout(shimmer, 5000 + Math.random() * 7000);
    };
    this.shimmerTimer = window.setTimeout(shimmer, 3000);
  }

  stopAmbient() {
    if (!this.ctx || !this.ambientGain) return;
    const now = this.ctx.currentTime;
    this.ambientGain.gain.cancelScheduledValues(now);
    this.ambientGain.gain.setValueAtTime(this.ambientGain.gain.value, now);
    this.ambientGain.gain.linearRampToValueAtTime(0, now + 1.2);
    const nodes = this.ambientNodes;
    const timer = this.shimmerTimer;
    window.setTimeout(() => {
      nodes.forEach((n) => {
        try {
          n.stop();
        } catch {
          /* already stopped */
        }
      });
    }, 1400);
    if (timer) window.clearTimeout(timer);
    this.ambientNodes = [];
    this.shimmerTimer = null;
    this.started = false;
  }

  private playBell(freq: number, vol: number, dur: number) {
    const ctx = this.ensureContext();
    if (!ctx || !this.master) return;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = freq;
    const g = ctx.createGain();
    const now = ctx.currentTime;
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(vol, now + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    osc.connect(g).connect(this.master);
    osc.start(now);
    osc.stop(now + dur + 0.05);
  }

  /** Play a short effect. Honours sfxEnabled. */
  play(name: Sfx) {
    if (!this.sfxEnabled) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    switch (name) {
      case 'sparkle': {
        [0, 4, 7, 12].forEach((s, i) =>
          window.setTimeout(() => this.playBell(midiToFreq(s + 12), 0.05, 0.5), i * 55),
        );
        break;
      }
      case 'open': {
        [0, 7, 12, 16].forEach((s, i) =>
          window.setTimeout(() => this.playBell(midiToFreq(s + 7), 0.06, 0.9), i * 90),
        );
        break;
      }
      case 'achievement': {
        [0, 12].forEach((s, i) =>
          window.setTimeout(() => this.playBell(midiToFreq(s + 12), 0.07, 0.8), i * 130),
        );
        break;
      }
      case 'heart': {
        this.playBell(midiToFreq(9 + 12), 0.05, 0.45);
        break;
      }
      case 'pop': {
        this.playBell(midiToFreq(12), 0.04, 0.18);
        break;
      }
    }
  }
}

/** A single shared engine for the whole app. */
export const audioEngine = new AudioEngine();
