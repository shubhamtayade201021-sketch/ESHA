import type { Note, Rarity, Mood, CategoryId } from './types';
import { MOOD_META } from './categories';

// ─── Rarity ─────────────────────────────────────────────────────────────────

/** Base rarity per category when a note doesn't specify its own. */
const DEFAULT_RARITY: Partial<Record<CategoryId, Rarity>> = {
  'love-letter': 'uncommon',
  'date-idea': 'uncommon',
  surprise: 'uncommon',
};

export function rarityOf(note: Note): Rarity {
  return note.rarity ?? DEFAULT_RARITY[note.category] ?? 'common';
}

/** Confetti only fires sometimes — tuned per rarity. */
export function confettiChance(rarity: Rarity): number {
  switch (rarity) {
    case 'legendary':
      return 1;
    case 'rare':
      return 0.85;
    case 'uncommon':
      return 0.4;
    default:
      return 0.18; // common: a rare little burst
  }
}

// ─── Easter-egg rolls ───────────────────────────────────────────────────────

export type EasterEgg = 'legendary' | 'heart-rain' | 'pixel-cat' | 'ghost-bunny' | 'fireworks' | null;

/**
 * Roll for a special event. Legendary ≈ 1 in 100; the rarer creatures are
 * even less frequent. Returns at most one egg so the screen never overloads.
 */
export function rollEasterEgg(rng: () => number = Math.random): EasterEgg {
  const r = rng();
  if (r < 0.01) return 'legendary'; // 1%
  if (r < 0.018) return 'pixel-cat'; // 0.8%
  if (r < 0.024) return 'ghost-bunny'; // 0.6%
  if (r < 0.032) return 'fireworks'; // 0.8%
  if (r < 0.05) return 'heart-rain'; // ~1.8%
  return null;
}

// ─── Weighted selection ─────────────────────────────────────────────────────

/**
 * Pick a note. When a mood is active, notes in that mood's comfort categories
 * are weighted more heavily. Soothing moods boost comfort even further so that
 * a sad/anxious tap is far more likely to land on something gentle.
 *
 * `avoidId` softly avoids repeating the exact note you just saw.
 */
export function pickNote(
  notes: Note[],
  mood: Mood | null,
  avoidId?: string,
  rng: () => number = Math.random,
): Note {
  if (notes.length === 0) {
    throw new Error('No notes available to pick from.');
  }

  const comfort = mood ? new Set(MOOD_META[mood].comfort) : null;
  const soothing = mood ? MOOD_META[mood].soothing : false;
  const boost = soothing ? 6 : 3;

  let total = 0;
  const weights = notes.map((n) => {
    let w = 1;
    if (comfort && comfort.has(n.category)) w *= boost;
    if (avoidId && n.id === avoidId) w *= 0.15; // discourage immediate repeat
    total += w;
    return w;
  });

  let roll = rng() * total;
  for (let i = 0; i < notes.length; i++) {
    roll -= weights[i];
    if (roll <= 0) return notes[i];
  }
  return notes[notes.length - 1];
}

/** Sparkle intensity (particle count) per rarity. */
export function sparkleCount(rarity: Rarity): number {
  switch (rarity) {
    case 'legendary':
      return 60;
    case 'rare':
      return 36;
    case 'uncommon':
      return 22;
    default:
      return 14;
  }
}
