// ─── Core domain types ──────────────────────────────────────────────────────

/** The category id. Keep in sync with CATEGORY_META below and messages.json. */
export type CategoryId =
  | 'love-reason'
  | 'compliment'
  | 'joke'
  | 'animal'
  | 'song'
  | 'movie'
  | 'memory'
  | 'love-letter'
  | 'challenge'
  | 'self-care'
  | 'adhd'
  | 'date-idea'
  | 'bedtime'
  | 'good-morning'
  | 'coupon'
  | 'kiss'
  | 'hug'
  | 'surprise';

/** Rarity tiers control sparkle level, confetti, and easter eggs. */
export type Rarity = 'common' | 'uncommon' | 'rare' | 'legendary';

/** Optional inline action attached to a note (e.g. a redeemable coupon). */
export interface NoteButton {
  label: string;
  /** A short message shown when tapped (no navigation, fully offline). */
  reveal?: string;
  /** Optional external link (song/movie). Opens in a new tab. */
  href?: string;
}

/** A single surprise inside the jar. */
export interface Note {
  id: string;
  category: CategoryId;
  title: string;
  message: string;
  emoji: string;
  /** Relative path inside /public, e.g. "photos/us-beach.jpg". Optional. */
  image?: string;
  /** Relative path inside /public, e.g. "audio/song.mp3". Optional. */
  audio?: string;
  /** Relative path to a Lottie/animation JSON in /public/animations. Optional. */
  animation?: string;
  /** Optional inline button. */
  button?: NoteButton;
  /** Overrides the category's default rarity. */
  rarity?: Rarity;
}

/** Display metadata for a category — drives accent colour + label. */
export interface CategoryMeta {
  id: CategoryId;
  label: string;
  emoji: string;
  /** Tailwind-friendly accent token used by NoteCard. */
  accent: AccentKey;
}

export type AccentKey = 'rose' | 'lilac' | 'mint' | 'peach' | 'sky' | 'glow';

/** Moods the user can set. */
export type Mood =
  | 'happy'
  | 'anxious'
  | 'overthinking'
  | 'sad'
  | 'excited'
  | 'tired';

export interface MoodMeta {
  id: Mood;
  label: string;
  emoji: string;
  /** Categories to boost when this mood is active. */
  comfort: CategoryId[];
  /** Whether this mood softens the whole UI (Comfort Mode). */
  soothing: boolean;
}

/** A note that has been opened and saved to the collection. */
export interface SavedNote {
  noteId: string;
  openedAt: number;
  rarity: Rarity;
  favorite: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  emoji: string;
  /** Returns true when unlocked, given current stats. */
  threshold: (s: AchievementStats) => boolean;
}

export interface AchievementStats {
  totalOpens: number;
  uniqueNotes: number;
  favorites: number;
  legendaryFound: number;
  categoriesSeen: number;
  moodsUsed: number;
}

export interface Preferences {
  musicOn: boolean;
  reducedMotion: boolean;
  soundEffects: boolean;
}
