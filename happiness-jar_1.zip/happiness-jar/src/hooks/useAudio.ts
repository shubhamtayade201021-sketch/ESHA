import { useCallback, useEffect } from 'react';
import { audioEngine } from '../lib/audio-engine';
import type { Preferences } from '../lib/types';

type Sfx = 'sparkle' | 'open' | 'achievement' | 'heart' | 'pop';

/**
 * Bridges preferences to the shared audio engine. Returns a stable `sfx`
 * function and keeps the ambient pad in sync with `prefs.musicOn`.
 */
export function useAudio(prefs: Preferences) {
  // Keep the engine's sfx flag in sync.
  useEffect(() => {
    audioEngine.sfxEnabled = prefs.soundEffects;
  }, [prefs.soundEffects]);

  // Start/stop ambient music when toggled.
  useEffect(() => {
    if (prefs.musicOn) {
      audioEngine.startAmbient();
    } else {
      audioEngine.stopAmbient();
    }
  }, [prefs.musicOn]);

  const sfx = useCallback((name: Sfx) => {
    audioEngine.play(name);
  }, []);

  return { sfx };
}
