import { useCallback, useMemo } from 'react';
import { useLocalStorage } from './useLocalStorage';
import { useSystemReducedMotion } from './useReducedMotion';
import { STORAGE_KEYS } from '../lib/storage-keys';
import { CATEGORY_ORDER } from '../lib/categories';
import { ACHIEVEMENTS } from '../lib/achievements';
import { pickNote, rarityOf, rollEasterEgg, confettiChance, type EasterEgg } from '../lib/rarity';
import rawNotes from '../data/messages.json';
import type {
  Note,
  SavedNote,
  Mood,
  Preferences,
  AchievementStats,
  Rarity,
} from '../lib/types';

const NOTES = rawNotes as Note[];
const NOTES_BY_ID = new Map(NOTES.map((n) => [n.id, n]));

export interface OpenResult {
  note: Note;
  rarity: Rarity;
  easterEgg: EasterEgg;
  confetti: boolean;
}

interface Meta {
  totalOpens: number;
  legendaryFound: number;
  moodsUsed: Mood[];
  lastNoteId: string | null;
}

const DEFAULT_PREFS: Preferences = {
  musicOn: false,
  reducedMotion: false,
  soundEffects: true,
};

const DEFAULT_META: Meta = {
  totalOpens: 0,
  legendaryFound: 0,
  moodsUsed: [],
  lastNoteId: null,
};

export function useJarApp() {
  const [prefs, setPrefs] = useLocalStorage<Preferences>(STORAGE_KEYS.prefs, DEFAULT_PREFS);
  const [mood, setMoodRaw] = useLocalStorage<Mood | null>(STORAGE_KEYS.mood, null);
  const [saved, setSaved] = useLocalStorage<SavedNote[]>(STORAGE_KEYS.saved, []);
  const [meta, setMeta] = useLocalStorage<Meta>(STORAGE_KEYS.lastOpen, DEFAULT_META);
  const [seenAchievements, setSeenAchievements] = useLocalStorage<string[]>(
    STORAGE_KEYS.achievements,
    [],
  );

  const systemReduced = useSystemReducedMotion();
  const reducedMotion = prefs.reducedMotion || systemReduced;

  // ── Derived stats ──────────────────────────────────────────────────────────
  const stats: AchievementStats = useMemo(() => {
    const uniqueIds = new Set(saved.map((s) => s.noteId));
    const cats = new Set<string>();
    let favorites = 0;
    for (const s of saved) {
      const note = NOTES_BY_ID.get(s.noteId);
      if (note) cats.add(note.category);
      if (s.favorite) favorites++;
    }
    return {
      totalOpens: meta.totalOpens,
      uniqueNotes: uniqueIds.size,
      favorites,
      legendaryFound: meta.legendaryFound,
      categoriesSeen: cats.size,
      moodsUsed: meta.moodsUsed.length,
    };
  }, [saved, meta]);

  // ── Achievements ───────────────────────────────────────────────────────────
  const unlockedIds = useMemo(
    () => new Set(ACHIEVEMENTS.filter((a) => a.threshold(stats)).map((a) => a.id)),
    [stats],
  );

  const newlyUnlocked = useMemo(
    () => ACHIEVEMENTS.filter((a) => unlockedIds.has(a.id) && !seenAchievements.includes(a.id)),
    [unlockedIds, seenAchievements],
  );

  const acknowledgeAchievements = useCallback(() => {
    setSeenAchievements(Array.from(unlockedIds));
  }, [unlockedIds, setSeenAchievements]);

  // ── Mood ─────────────────────────────────────────────────────────────────--
  const setMood = useCallback(
    (next: Mood | null) => {
      setMoodRaw(next);
      if (next) {
        setMeta((m) => (m.moodsUsed.includes(next) ? m : { ...m, moodsUsed: [...m.moodsUsed, next] }));
      }
    },
    [setMoodRaw, setMeta],
  );

  // ── The core action: open the jar ──────────────────────────────────────────
  const open = useCallback((): OpenResult => {
    const note = pickNote(NOTES, mood, meta.lastNoteId ?? undefined);
    const baseRarity = rarityOf(note);
    const egg = rollEasterEgg();
    // A legendary easter egg upgrades the note's perceived rarity.
    const rarity: Rarity = egg === 'legendary' ? 'legendary' : baseRarity;
    const confetti = Math.random() < confettiChance(rarity);

    setMeta((m) => ({
      ...m,
      totalOpens: m.totalOpens + 1,
      legendaryFound: egg === 'legendary' ? m.legendaryFound + 1 : m.legendaryFound,
      lastNoteId: note.id,
    }));

    // Save to collection (keep first-seen time; bump nothing if already saved).
    setSaved((prev) => {
      if (prev.some((s) => s.noteId === note.id)) return prev;
      const entry: SavedNote = {
        noteId: note.id,
        openedAt: Date.now(),
        rarity,
        favorite: false,
      };
      return [entry, ...prev];
    });

    return { note, rarity, easterEgg: egg, confetti };
  }, [mood, meta.lastNoteId, setMeta, setSaved]);

  // ── Collection actions ─────────────────────────────────────────────────────
  const toggleFavorite = useCallback(
    (noteId: string) => {
      setSaved((prev) =>
        prev.map((s) => (s.noteId === noteId ? { ...s, favorite: !s.favorite } : s)),
      );
    },
    [setSaved],
  );

  const resolveNote = useCallback((id: string) => NOTES_BY_ID.get(id), []);

  // ── Preference helpers ─────────────────────────────────────────────────────
  const toggleMusic = useCallback(() => setPrefs((p) => ({ ...p, musicOn: !p.musicOn })), [setPrefs]);
  const toggleReducedMotion = useCallback(
    () => setPrefs((p) => ({ ...p, reducedMotion: !p.reducedMotion })),
    [setPrefs],
  );
  const toggleSfx = useCallback(
    () => setPrefs((p) => ({ ...p, soundEffects: !p.soundEffects })),
    [setPrefs],
  );

  return {
    notes: NOTES,
    totalCategories: CATEGORY_ORDER.length,
    prefs,
    setPrefs,
    toggleMusic,
    toggleReducedMotion,
    toggleSfx,
    reducedMotion,
    mood,
    setMood,
    saved,
    stats,
    open,
    toggleFavorite,
    resolveNote,
    achievements: ACHIEVEMENTS,
    unlockedIds,
    newlyUnlocked,
    acknowledgeAchievements,
  };
}

export type JarApp = ReturnType<typeof useJarApp>;
