import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Modal } from './ui/Modal';
import { NoteCard } from './NoteCard';
import type { OpenResult } from '../hooks/useJarApp';

interface Props {
  result: OpenResult | null;
  open: boolean;
  onClose: () => void;
  onAnother: () => void;
  favorite: boolean;
  onToggleFavorite: (id: string) => void;
  reducedMotion: boolean;
}

/** Plays the paper-unfold reveal, then shows the note with actions. */
export function NoteReveal({
  result,
  open,
  onClose,
  onAnother,
  favorite,
  onToggleFavorite,
  reducedMotion,
}: Props) {
  const [unfolded, setUnfolded] = useState(reducedMotion);

  // Each new result restarts the fold → unfold sequence.
  useEffect(() => {
    if (!result) return;
    if (reducedMotion) {
      setUnfolded(true);
      return;
    }
    setUnfolded(false);
    const t = window.setTimeout(() => setUnfolded(true), 900);
    return () => window.clearTimeout(t);
  }, [result, reducedMotion]);

  return (
    <Modal open={open && !!result} onClose={onClose} title="A surprise for you" bare labelId="reveal-title">
      {result && (
        <div className="p-5 sm:p-6">
          <h2 id="reveal-title" className="sr-only">
            {result.note.title}
          </h2>

          <AnimatePresence mode="wait">
            {!unfolded ? (
              <motion.div
                key="folding"
                className="grid h-64 place-items-center"
                exit={{ opacity: 0, scale: 0.8 }}
              >
                <motion.div
                  className="grid h-24 w-24 place-items-center rounded-2xl bg-gradient-to-br from-glow-200 to-glow-500 text-4xl shadow-glow"
                  initial={{ y: 120, rotate: -12, opacity: 0, scale: 0.6 }}
                  animate={{
                    y: [120, -10, 0],
                    rotate: [-12, 8, 0],
                    opacity: 1,
                    scale: [0.6, 1.1, 1],
                  }}
                  transition={{ duration: 0.85, ease: 'easeOut' }}
                >
                  <span aria-hidden="true">{result.note.emoji}</span>
                </motion.div>
              </motion.div>
            ) : (
              <motion.div
                key="note"
                initial={reducedMotion ? false : { rotateX: 80, opacity: 0, y: 20 }}
                animate={{ rotateX: 0, opacity: 1, y: 0 }}
                transition={{ type: 'spring', stiffness: 220, damping: 22 }}
                style={{ transformPerspective: 900 }}
              >
                <NoteCard
                  note={result.note}
                  rarity={result.rarity}
                  favorite={favorite}
                  onToggleFavorite={onToggleFavorite}
                />
              </motion.div>
            )}
          </AnimatePresence>

          {unfolded && (
            <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={onAnother}
                className="rounded-full bg-gradient-to-r from-glow-200 to-glow-500 px-6 py-3 font-bold text-night-900 shadow-glow transition hover:brightness-105"
              >
                Open another ✨
              </button>
              <button
                type="button"
                onClick={onClose}
                className="rounded-full px-6 py-3 font-semibold text-ink/90 glass transition hover:bg-night-600/70"
              >
                Keep it close
              </button>
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}
