import { Modal } from './ui/Modal';
import type { Preferences } from '../lib/types';

interface Props {
  open: boolean;
  onClose: () => void;
  prefs: Preferences;
  /** True when the OS itself is requesting reduced motion. */
  systemReducedMotion: boolean;
  onToggleMusic: () => void;
  onToggleSfx: () => void;
  onToggleReducedMotion: () => void;
}

interface ToggleRowProps {
  id: string;
  title: string;
  description: string;
  emoji: string;
  checked: boolean;
  disabled?: boolean;
  hint?: string;
  onChange: () => void;
}

/** A single labelled switch row. */
function ToggleRow({ id, title, description, emoji, checked, disabled = false, hint, onChange }: ToggleRowProps) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-2xl bg-night-700/50 px-4 py-3.5">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 text-2xl" aria-hidden="true">
          {emoji}
        </span>
        <div>
          <label htmlFor={id} className="font-display text-base font-semibold text-ink">
            {title}
          </label>
          <p className="text-sm text-muted">{description}</p>
          {hint && <p className="mt-0.5 text-xs text-glow-200/90">{hint}</p>}
        </div>
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={onChange}
        className={[
          'relative h-7 w-12 shrink-0 rounded-full transition-colors',
          checked ? 'bg-glow-400' : 'bg-night-800',
          disabled ? 'cursor-not-allowed opacity-60' : 'cursor-pointer',
        ].join(' ')}
      >
        <span
          aria-hidden="true"
          className={[
            'absolute top-0.5 grid h-6 w-6 place-items-center rounded-full bg-white text-[11px] shadow transition-transform',
            checked ? 'translate-x-[1.35rem]' : 'translate-x-0.5',
          ].join(' ')}
        >
          {checked ? '✓' : ''}
        </span>
      </button>
    </div>
  );
}

/** A small settings dialog for music, sound effects, and motion. */
export function SettingsPanel({
  open,
  onClose,
  prefs,
  systemReducedMotion,
  onToggleMusic,
  onToggleSfx,
  onToggleReducedMotion,
}: Props) {
  return (
    <Modal open={open} onClose={onClose} title="Settings">
      <div className="space-y-3 p-5">
        <ToggleRow
          id="set-music"
          title="Ambient music"
          description="A soft, gentle background melody."
          emoji="🎵"
          checked={prefs.musicOn}
          onChange={onToggleMusic}
        />
        <ToggleRow
          id="set-sfx"
          title="Sound effects"
          description="Little chimes and sparkles on each tap."
          emoji="🔔"
          checked={prefs.soundEffects}
          onChange={onToggleSfx}
        />
        <ToggleRow
          id="set-motion"
          title="Reduce motion"
          description="Calmer animations and gentler transitions."
          emoji="🍃"
          checked={prefs.reducedMotion || systemReducedMotion}
          disabled={systemReducedMotion}
          hint={systemReducedMotion ? 'Your device already has reduced motion turned on.' : undefined}
          onChange={onToggleReducedMotion}
        />

        <p className="px-1 pt-2 text-center text-xs text-muted">
          Everything you open is saved privately on this device. ✨
        </p>
      </div>
    </Modal>
  );
}
