import { useEffect } from 'react';
import { motion } from 'framer-motion';

interface Props {
  onDone: () => void;
  reducedMotion: boolean;
}

/** A friendly translucent ghost bunny that floats up and fades. */
export function GhostBunny({ onDone, reducedMotion }: Props) {
  useEffect(() => {
    const t = window.setTimeout(onDone, reducedMotion ? 1200 : 5000);
    return () => window.clearTimeout(t);
  }, [onDone, reducedMotion]);

  return (
    <div className="pointer-events-none fixed inset-0 z-40 grid place-items-end justify-center pb-24" aria-hidden="true">
      <motion.div
        initial={{ y: 60, opacity: 0, scale: 0.8 }}
        animate={{ y: reducedMotion ? 0 : -240, opacity: [0, 0.95, 0.95, 0], scale: 1 }}
        transition={{ duration: reducedMotion ? 1 : 4.6, ease: 'easeOut' }}
      >
        <motion.svg
          width="96"
          height="120"
          viewBox="0 0 48 60"
          animate={reducedMotion ? {} : { rotate: [0, -4, 4, 0] }}
          transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
        >
          {/* ears */}
          <ellipse cx="18" cy="12" rx="5" ry="13" fill="#eae6ff" opacity="0.85" />
          <ellipse cx="30" cy="12" rx="5" ry="13" fill="#eae6ff" opacity="0.85" />
          <ellipse cx="18" cy="12" rx="2.4" ry="9" fill="#ffd3e6" opacity="0.7" />
          <ellipse cx="30" cy="12" rx="2.4" ry="9" fill="#ffd3e6" opacity="0.7" />
          {/* head/body wisp */}
          <path
            d="M10 30 Q10 18 24 18 Q38 18 38 30 L38 44 Q38 52 24 56 Q10 52 10 44 Z"
            fill="#f1eeff"
            opacity="0.9"
          />
          {/* eyes */}
          <circle cx="19" cy="32" r="2" fill="#3a3147" />
          <circle cx="29" cy="32" r="2" fill="#3a3147" />
          {/* cheeks */}
          <circle cx="15" cy="37" r="2.2" fill="#ffc2dd" opacity="0.8" />
          <circle cx="33" cy="37" r="2.2" fill="#ffc2dd" opacity="0.8" />
          {/* tiny smile */}
          <path d="M22 38 Q24 41 26 38" stroke="#3a3147" strokeWidth="1.2" fill="none" />
        </motion.svg>
      </motion.div>
    </div>
  );
}
