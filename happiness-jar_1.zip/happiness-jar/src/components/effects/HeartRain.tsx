import { useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';

interface Props {
  onDone: () => void;
  reducedMotion: boolean;
}

/** A short shower of hearts. Auto-dismisses. */
export function HeartRain({ onDone, reducedMotion }: Props) {
  const hearts = useMemo(
    () =>
      Array.from({ length: reducedMotion ? 10 : 26 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 1.5,
        dur: 3 + Math.random() * 2,
        size: 16 + Math.random() * 22,
        emoji: ['❤️', '💖', '💕', '🩷'][i % 4],
      })),
    [reducedMotion],
  );

  useEffect(() => {
    const t = window.setTimeout(onDone, 4500);
    return () => window.clearTimeout(t);
  }, [onDone]);

  return (
    <div className="pointer-events-none fixed inset-0 z-40" aria-hidden="true">
      {hearts.map((h) => (
        <motion.span
          key={h.id}
          className="absolute -top-10"
          style={{ left: `${h.left}%`, fontSize: h.size }}
          initial={{ y: -40, opacity: 0 }}
          animate={{ y: '110vh', opacity: [0, 1, 1, 0], rotate: [0, 20, -20, 0] }}
          transition={{ duration: h.dur, delay: h.delay, ease: 'easeIn' }}
        >
          {h.emoji}
        </motion.span>
      ))}
    </div>
  );
}
