import { useEffect } from 'react';
import { motion } from 'framer-motion';

interface Props {
  onDone: () => void;
  reducedMotion: boolean;
}

/** A tiny pixel cat that walks across the screen once. */
export function PixelCat({ onDone, reducedMotion }: Props) {
  useEffect(() => {
    const t = window.setTimeout(onDone, reducedMotion ? 1200 : 6500);
    return () => window.clearTimeout(t);
  }, [onDone, reducedMotion]);

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-3 z-40 h-16" aria-hidden="true">
      <motion.div
        className="absolute bottom-0"
        initial={{ x: '-12vw' }}
        animate={{ x: reducedMotion ? '40vw' : '112vw' }}
        transition={{ duration: reducedMotion ? 1 : 6, ease: 'linear' }}
      >
        {/* Little bob while walking */}
        <motion.svg
          width="56"
          height="44"
          viewBox="0 0 28 22"
          shapeRendering="crispEdges"
          animate={reducedMotion ? {} : { y: [0, -2, 0] }}
          transition={{ duration: 0.4, repeat: Infinity }}
        >
          {/* body */}
          <rect x="4" y="9" width="16" height="8" fill="#3a3147" />
          <rect x="4" y="9" width="16" height="8" fill="#c5b3ff" opacity="0.85" />
          {/* head */}
          <rect x="16" y="5" width="8" height="8" fill="#c5b3ff" />
          {/* ears */}
          <rect x="16" y="3" width="2" height="2" fill="#c5b3ff" />
          <rect x="22" y="3" width="2" height="2" fill="#c5b3ff" />
          {/* eye */}
          <rect x="21" y="8" width="2" height="2" fill="#2b2438" />
          {/* tail */}
          <rect x="2" y="6" width="2" height="6" fill="#c5b3ff" />
          <rect x="0" y="4" width="2" height="4" fill="#c5b3ff" />
          {/* legs */}
          <rect x="6" y="17" width="2" height="3" fill="#a48fe0" />
          <rect x="16" y="17" width="2" height="3" fill="#a48fe0" />
        </motion.svg>
      </motion.div>
    </div>
  );
}
