import { useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';

interface Props {
  onDone: () => void;
  reducedMotion: boolean;
}

const RAINBOW = ['#ff8fb1', '#ffd79a', '#fff3a8', '#a8e6cf', '#a8d8ff', '#c5b3ff'];

/** The legendary celebration: rainbow stars, a gold wash, and a banner. */
export function LegendaryOverlay({ onDone, reducedMotion }: Props) {
  const stars = useMemo(
    () =>
      Array.from({ length: reducedMotion ? 16 : 60 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        top: Math.random() * 100,
        size: 6 + Math.random() * 14,
        color: RAINBOW[i % RAINBOW.length],
        delay: Math.random() * 1.5,
      })),
    [reducedMotion],
  );

  useEffect(() => {
    const t = window.setTimeout(onDone, 4000);
    return () => window.clearTimeout(t);
  }, [onDone]);

  return (
    <motion.div
      className="pointer-events-none fixed inset-0 z-[45]"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      aria-hidden="true"
    >
      {/* Warm golden wash */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(80% 60% at 50% 40%, rgba(255,210,120,0.35), rgba(255,150,80,0.12) 50%, transparent 75%)',
        }}
      />

      {/* Rainbow stars */}
      {stars.map((s) => (
        <motion.span
          key={s.id}
          className="absolute"
          style={{ left: `${s.left}%`, top: `${s.top}%`, fontSize: s.size, color: s.color }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: [0, 1, 0.6, 1, 0], scale: [0, 1.2, 0.9, 1.1, 0] }}
          transition={{ duration: 3.2, delay: s.delay, repeat: Infinity, repeatDelay: 0.4 }}
        >
          ✦
        </motion.span>
      ))}

      {/* Banner */}
      <div className="absolute inset-x-0 top-[14%] grid place-items-center px-6">
        <motion.div
          className="rounded-3xl px-7 py-5 text-center shadow-glow-lg"
          style={{ background: 'linear-gradient(135deg, rgba(255,246,230,0.95), rgba(255,210,120,0.92))' }}
          initial={{ y: -30, scale: 0.85, opacity: 0 }}
          animate={{ y: 0, scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 200, damping: 16 }}
        >
          <p className="font-display text-sm font-bold uppercase tracking-widest text-[#a8772c]">
            Legendary find
          </p>
          <p className="mt-1 font-display text-2xl font-bold text-night-900">
            You found the Legendary Love Letter 👑
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
}
