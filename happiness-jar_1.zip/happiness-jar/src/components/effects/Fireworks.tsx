import { useEffect } from 'react';
import confetti from 'canvas-confetti';

interface Props {
  onDone: () => void;
  reducedMotion: boolean;
}

const COLORS = ['#ffb3d1', '#c5b3ff', '#a8e6cf', '#ffd3b6', '#a8d8ff', '#ffd79a'];

/** A few celebratory firework bursts, then done. */
export function Fireworks({ onDone, reducedMotion }: Props) {
  useEffect(() => {
    if (reducedMotion) {
      onDone();
      return;
    }
    const end = Date.now() + 2400;
    let raf = 0;

    const burst = () => {
      confetti({
        particleCount: 40,
        startVelocity: 38,
        spread: 360,
        ticks: 70,
        origin: { x: Math.random() * 0.8 + 0.1, y: Math.random() * 0.4 + 0.1 },
        colors: COLORS,
        scalar: 1.1,
        disableForReducedMotion: true,
      });
      if (Date.now() < end) {
        raf = window.setTimeout(burst, 350) as unknown as number;
      } else {
        onDone();
      }
    };
    burst();

    return () => window.clearTimeout(raf);
  }, [onDone, reducedMotion]);

  return null;
}
