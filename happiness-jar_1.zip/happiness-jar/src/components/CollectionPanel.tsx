import { useMemo, useState } from 'react';
import { Modal } from './ui/Modal';
import { NoteCard } from './NoteCard';
import type { Note, SavedNote } from '../lib/types';
import { CATEGORY_META } from '../lib/categories';

interface Props {
  open: boolean;
  onClose: () => void;
  saved: SavedNote[];
  resolveNote: (id: string) => Note | undefined;
  onToggleFavorite: (id: string) => void;
}

type Tab = 'all' | 'favourites';

/** The archive of everything opened so far, with search and favourites. */
export function CollectionPanel({ open, onClose, saved, resolveNote, onToggleFavorite }: Props) {
  const [tab, setTab] = useState<Tab>('all');
  const [query, setQuery] = useState('');

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return saved
      .map((s) => ({ saved: s, note: resolveNote(s.noteId) }))
      .filter((r): r is { saved: SavedNote; note: Note } => !!r.note)
      .filter((r) => (tab === 'favourites' ? r.saved.favorite : true))
      .filter((r) => {
        if (!q) return true;
        const label = CATEGORY_META[r.note.category].label.toLowerCase();
        return (
          r.note.title.toLowerCase().includes(q) ||
          r.note.message.toLowerCase().includes(q) ||
          label.includes(q)
        );
      });
  }, [saved, resolveNote, tab, query]);

  const favCount = saved.filter((s) => s.favorite).length;

  return (
    <Modal open={open} onClose={onClose} title="Your memory collection">
      <div className="p-5">
        <div className="flex items-center gap-2">
          <div className="flex rounded-full bg-night-700/70 p-1 text-sm">
            <button
              type="button"
              onClick={() => setTab('all')}
              className={['rounded-full px-3 py-1.5 font-semibold transition', tab === 'all' ? 'bg-lilac-soft/30 text-ink' : 'text-muted'].join(' ')}
            >
              All {saved.length > 0 && `(${saved.length})`}
            </button>
            <button
              type="button"
              onClick={() => setTab('favourites')}
              className={['rounded-full px-3 py-1.5 font-semibold transition', tab === 'favourites' ? 'bg-rose-soft/30 text-ink' : 'text-muted'].join(' ')}
            >
              💖 Favourites {favCount > 0 && `(${favCount})`}
            </button>
          </div>
        </div>

        <div className="mt-3">
          <label htmlFor="memory-search" className="sr-only">
            Search your notes
          </label>
          <input
            id="memory-search"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search your surprises…"
            className="w-full rounded-full border border-lilac-soft/20 bg-night-700/60 px-4 py-2.5 text-ink placeholder:text-muted/70 focus:border-lilac-soft focus:outline-none"
          />
        </div>

        {rows.length === 0 ? (
          <p className="mt-10 text-center text-muted">
            {saved.length === 0
              ? 'Nothing here yet — open the jar to start collecting little moments. ✨'
              : tab === 'favourites'
                ? 'No favourites yet. Tap the heart on a note to keep it here. 💖'
                : 'No notes match that search.'}
          </p>
        ) : (
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {rows.map(({ saved: s, note }) => (
              <NoteCard
                key={s.noteId}
                note={note}
                rarity={s.rarity}
                favorite={s.favorite}
                onToggleFavorite={onToggleFavorite}
                compact
              />
            ))}
          </div>
        )}
      </div>
    </Modal>
  );
}
