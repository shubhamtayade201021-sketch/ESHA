import { useEffect, useRef } from 'react';

interface Props {
  reducedMotion: boolean;
  /** Tints toward warm gold during the legendary easter egg. */
  legendary?: boolean;
}

interface Star {
  x: number;
  y: number;
  r: number;
  baseAlpha: number;
  twinkle: number;
  speed: number;
  hue: number;
}

/** A soft, slowly-drifting starfield rendered on a single canvas. */
export function StarsBackground({ reducedMotion, legendary = false }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);
    let raf = 0;
    let t = 0;

    const count = Math.min(160, Math.floor((width * height) / 9000));
    const stars: Star[] = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      r: Math.random() * 1.4 + 0.3,
      baseAlpha: Math.random() * 0.5 + 0.25,
      twinkle: Math.random() * Math.PI * 2,
      speed: Math.random() * 0.06 + 0.01,
      hue: Math.random() * 60 + 200, // bluish-violet
    }));

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      for (const s of stars) {
        s.twinkle += 0.02;
        const alpha = reducedMotion
          ? s.baseAlpha
          : s.baseAlpha + Math.sin(s.twinkle) * 0.25;
        const hue = legendary ? 45 : s.hue;
        const light = legendary ? 70 : 80;
        ctx.beginPath();
        ctx.fillStyle = `hsla(${hue}, ${legendary ? 90 : 60}%, ${light}%, ${Math.max(0, alpha)})`;
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();

        if (!reducedMotion) {
          s.y += s.speed;
          if (s.y > height + 2) {
            s.y = -2;
            s.x = Math.random() * width;
          }
        }
      }
      t += 1;
      raf = requestAnimationFrame(draw);
    };

    draw();

    const onResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', onResize);
    };
  }, [reducedMotion, legendary]);

  return (
    <canvas
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-0"
    />
  );
}
