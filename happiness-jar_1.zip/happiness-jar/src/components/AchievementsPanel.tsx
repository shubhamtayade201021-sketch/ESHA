import { Modal } from './ui/Modal';
import type { Achievement, AchievementStats } from '../lib/types';

interface Props {
  open: boolean;
  onClose: () => void;
  achievements: Achievement[];
  unlockedIds: Set<string>;
  stats: AchievementStats;
}

/** A grid of all achievements with their locked/unlocked state and overall progress. */
export function AchievementsPanel({ open, onClose, achievements, unlockedIds, stats }: Props) {
  const unlockedCount = unlockedIds.size;
  const total = achievements.length;
  const pct = total > 0 ? Math.round((unlockedCount / total) * 100) : 0;

  return (
    <Modal open={open} onClose={onClose} title="Achievements">
      <div className="p-5">
        {/* Progress header */}
        <div className="rounded-2xl bg-night-700/50 p-4">
          <div className="flex items-baseline justify-between">
            <p className="font-display text-lg font-semibold text-ink">
              {unlockedCount} of {total} unlocked
            </p>
            <p className="text-sm font-bold text-glow-200">{pct}%</p>
          </div>
          <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-night-800">
            <div
              className="h-full rounded-full bg-gradient-to-r from-glow-200 to-glow-500 transition-all duration-500"
              style={{ width: `${pct}%` }}
            />
          </div>
          <p className="mt-2 text-xs text-muted">
            {stats.totalOpens} {stats.totalOpens === 1 ? 'surprise' : 'surprises'} opened ·{' '}
            {stats.categoriesSeen}/18 categories seen
          </p>
        </div>

        {/* Achievement list */}
        <ul className="mt-4 grid gap-2.5 sm:grid-cols-2">
          {achievements.map((a) => {
            const unlocked = unlockedIds.has(a.id);
            return (
              <li
                key={a.id}
                className={[
                  'flex items-start gap-3 rounded-2xl px-4 py-3 transition',
                  unlocked
                    ? 'bg-gradient-to-br from-glow-200/15 to-glow-500/10 ring-1 ring-glow-400/40'
                    : 'bg-night-700/40',
                ].join(' ')}
              >
                <span
                  className={['grid h-10 w-10 shrink-0 place-items-center rounded-full text-xl', unlocked ? '' : 'opacity-40 grayscale'].join(' ')}
                  style={{ background: unlocked ? 'rgba(255,215,154,0.18)' : 'rgba(255,255,255,0.05)' }}
                  aria-hidden="true"
                >
                  {unlocked ? a.emoji : '🔒'}
                </span>
                <div className="min-w-0">
                  <p className={['font-display font-semibold', unlocked ? 'text-ink' : 'text-muted'].join(' ')}>
                    {a.title}
                  </p>
                  <p className="text-sm text-muted">{a.description}</p>
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </Modal>
  );
}
