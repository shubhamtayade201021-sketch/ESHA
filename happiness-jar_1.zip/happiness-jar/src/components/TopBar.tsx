import { IconButton } from './ui/IconButton';

interface Props {
  musicOn: boolean;
  onToggleMusic: () => void;
  onOpenCollection: () => void;
  onOpenAchievements: () => void;
  onOpenSettings: () => void;
  collectionCount: number;
  achievementsUnlocked: number;
  achievementsTotal: number;
}

/** A minimal, floating control bar in the top-right of the scene. */
export function TopBar({
  musicOn,
  onToggleMusic,
  onOpenCollection,
  onOpenAchievements,
  onOpenSettings,
  collectionCount,
  achievementsUnlocked,
  achievementsTotal,
}: Props) {
  return (
    <div className="fixed right-3 top-3 z-30 flex items-center gap-2 sm:right-5 sm:top-5">
      <IconButton label={musicOn ? 'Turn music off' : 'Turn music on'} active={musicOn} onClick={onToggleMusic}>
        {musicOn ? '🎵' : '🔇'}
      </IconButton>

      <div className="relative">
        <IconButton label="Open your memory collection" onClick={onOpenCollection}>
          📚
        </IconButton>
        {collectionCount > 0 && (
          <span className="absolute -right-1 -top-1 grid h-5 min-w-[1.25rem] place-items-center rounded-full bg-rose-soft px-1 text-[10px] font-bold text-night-900">
            {collectionCount > 99 ? '99+' : collectionCount}
          </span>
        )}
      </div>

      <div className="relative">
        <IconButton label="View achievements" onClick={onOpenAchievements}>
          🏆
        </IconButton>
        <span className="absolute -right-1 -top-1 grid h-5 min-w-[1.25rem] place-items-center rounded-full bg-glow-400 px-1 text-[10px] font-bold text-night-900">
          {achievementsUnlocked}/{achievementsTotal}
        </span>
      </div>

      <IconButton label="Open settings" onClick={onOpenSettings}>
        ⚙️
      </IconButton>
    </div>
  );
}
