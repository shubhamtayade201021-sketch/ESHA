import { AnimatePresence } from 'framer-motion';
import type { EasterEgg } from '../lib/rarity';
import { HeartRain } from './effects/HeartRain';
import { PixelCat } from './effects/PixelCat';
import { GhostBunny } from './effects/GhostBunny';
import { Fireworks } from './effects/Fireworks';
import { LegendaryOverlay } from './effects/LegendaryOverlay';

interface Props {
  egg: EasterEgg;
  onDone: () => void;
  reducedMotion: boolean;
}

/** Renders whichever rare effect is currently active. */
export function EffectsLayer({ egg, onDone, reducedMotion }: Props) {
  return (
    <AnimatePresence>
      {egg === 'heart-rain' && <HeartRain key="hr" onDone={onDone} reducedMotion={reducedMotion} />}
      {egg === 'pixel-cat' && <PixelCat key="pc" onDone={onDone} reducedMotion={reducedMotion} />}
      {egg === 'ghost-bunny' && <GhostBunny key="gb" onDone={onDone} reducedMotion={reducedMotion} />}
      {egg === 'fireworks' && <Fireworks key="fw" onDone={onDone} reducedMotion={reducedMotion} />}
      {egg === 'legendary' && <LegendaryOverlay key="lg" onDone={onDone} reducedMotion={reducedMotion} />}
    </AnimatePresence>
  );
}
