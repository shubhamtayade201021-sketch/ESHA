import { motion } from 'framer-motion';

interface Props {
  onClick: () => void;
  disabled?: boolean;
  reducedMotion: boolean;
  label?: string;
}

/** The primary call to action — a warm, glowing pill that invites a tap. */
export function OpenButton({ onClick, disabled = false, reducedMotion, label = 'Open the Jar' }: Props) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      disabled={disabled}
      whileHover={reducedMotion ? undefined : { scale: 1.04 }}
      whileTap={reducedMotion ? undefined : { scale: 0.96 }}
      className={[
        'relative overflow-hidden rounded-full px-9 py-4 font-body text-lg font-extrabold',
        'text-night-900 shadow-glow transition-shadow disabled:opacity-60',
        reducedMotion ? '' : 'animate-pulse-glow',
      ].join(' ')}
      style={{
        background: 'linear-gradient(135deg, #ffe2b0 0%, #ffba6b 50%, #ffd3b6 100%)',
      }}
    >
      <span className="relative z-10 flex items-center gap-2">
        <span aria-hidden="true">✨</span>
        {disabled ? 'Opening…' : label}
      </span>
      {!reducedMotion && (
        <motion.span
          aria-hidden="true"
          className="absolute inset-0 -translate-x-full"
          style={{
            background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.55), transparent)',
          }}
          animate={{ x: ['-100%', '180%'] }}
          transition={{ duration: 2.6, repeat: Infinity, repeatDelay: 1.4, ease: 'easeInOut' }}
        />
      )}
    </motion.button>
  );
}
