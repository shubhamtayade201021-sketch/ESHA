import { motion } from 'framer-motion';
import { useMemo } from 'react';

interface Props {
  opening: boolean;
  reducedMotion: boolean;
  legendary?: boolean;
  soothing?: boolean;
}

/**
 * The hero of the whole experience. A hand-built glassy jar that gently
 * breathes when idle and performs a shake → lid-lift → light-pour sequence
 * when `opening` flips true. Colours shift gold for the legendary egg and
 * soften in Comfort Mode.
 */
export function Jar({ opening, reducedMotion, legendary = false, soothing = false }: Props) {
  // A few folded papers resting inside the jar (positions are stable per mount).
  const papers = useMemo(
    () =>
      Array.from({ length: 6 }, (_, i) => ({
        x: 96 + (i % 3) * 38 + (i > 2 ? 18 : 0),
        y: 250 + (i % 2) * 16,
        rot: (i * 37) % 40 - 20,
        hue: ['#ffd3b6', '#ffb3d1', '#c5b3ff', '#a8e6cf', '#a8d8ff', '#fff6e6'][i],
      })),
    [],
  );

  const glassTop = legendary ? '#fff1cf' : soothing ? '#b9b0e6' : '#cfe6ff';
  const glassBottom = legendary ? '#ffba6b' : soothing ? '#7c6fb8' : '#7fa9d8';
  const glowColor = legendary ? 'rgba(255,200,90,0.95)' : 'rgba(255,200,120,0.85)';

  // Ambient vs opening vs static (reduced motion) container animation.
  const containerAnimate = reducedMotion
    ? {}
    : opening
      ? { x: [0, -7, 7, -6, 5, -3, 0], rotate: [0, -2.5, 2.5, -1.5, 1.5, -0.5, 0] }
      : { y: [0, -9, 0] };

  const containerTransition = opening
    ? { duration: 0.55, ease: 'easeInOut' as const }
    : { duration: 6, repeat: Infinity, ease: 'easeInOut' as const };

  return (
    <div className="relative mx-auto w-[min(78vw,360px)] select-none">
      {/* Ground glow puddle under the jar */}
      <div
        aria-hidden="true"
        className="absolute inset-x-6 bottom-2 h-10 rounded-[50%] blur-2xl"
        style={{ background: glowColor, opacity: legendary ? 0.7 : 0.45 }}
      />

      <motion.div animate={containerAnimate} transition={containerTransition}>
        <svg
          viewBox="0 0 300 380"
          role="img"
          aria-label="A magical glowing jar full of folded notes"
          className="h-auto w-full overflow-visible"
        >
          <defs>
            <linearGradient id="glassBody" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={glassTop} stopOpacity="0.55" />
              <stop offset="55%" stopColor={glassBottom} stopOpacity="0.35" />
              <stop offset="100%" stopColor={glassBottom} stopOpacity="0.6" />
            </linearGradient>
            <radialGradient id="innerGlow" cx="50%" cy="78%" r="62%">
              <stop offset="0%" stopColor={legendary ? '#fff6e6' : '#ffe2b0'} stopOpacity="0.95" />
              <stop offset="45%" stopColor="#ffba6b" stopOpacity="0.55" />
              <stop offset="100%" stopColor="#ffba6b" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="beam" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#fff6e6" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#ffba6b" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="lid" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={legendary ? '#ffe9a8' : '#d8c4a0'} />
              <stop offset="100%" stopColor={legendary ? '#e0a23c' : '#b08f63'} />
            </linearGradient>
          </defs>

          {/* Pouring light beam (only while opening) */}
          {!reducedMotion && (
            <motion.path
              d="M150 70 L120 -40 L180 -40 Z"
              fill="url(#beam)"
              initial={{ opacity: 0, scaleY: 0.2 }}
              animate={opening ? { opacity: [0, 0.9, 0.5], scaleY: [0.2, 1, 1] } : { opacity: 0 }}
              transition={{ duration: 0.8, delay: opening ? 0.45 : 0, ease: 'easeOut' }}
              style={{ transformOrigin: '150px 70px' }}
            />
          )}

          {/* Glass body */}
          <path
            d="M72 118
               Q72 104 86 104
               L214 104
               Q228 104 228 118
               L228 300
               Q228 344 184 344
               L116 344
               Q72 344 72 300
               Z"
            fill="url(#glassBody)"
            stroke="rgba(255,255,255,0.35)"
            strokeWidth="2"
          />

          {/* Inner warm glow */}
          <ellipse cx="150" cy="300" rx="78" ry="70" fill="url(#innerGlow)" />

          {/* Folded papers inside */}
          {papers.map((p, i) => (
            <g key={i} transform={`translate(${p.x} ${p.y}) rotate(${p.rot})`}>
              <rect width="34" height="24" rx="3" fill={p.hue} opacity="0.92" />
              <rect width="34" height="24" rx="3" fill="rgba(0,0,0,0.06)" />
              <line x1="4" y1="12" x2="30" y2="12" stroke="rgba(0,0,0,0.12)" strokeWidth="1.4" />
            </g>
          ))}

          {/* Glass highlights */}
          <path
            d="M92 120 Q86 220 100 320"
            fill="none"
            stroke="rgba(255,255,255,0.45)"
            strokeWidth="6"
            strokeLinecap="round"
            opacity="0.6"
          />
          <path
            d="M206 130 Q212 210 202 300"
            fill="none"
            stroke="rgba(255,255,255,0.2)"
            strokeWidth="4"
            strokeLinecap="round"
          />

          {/* Neck rim */}
          <rect x="78" y="96" width="144" height="16" rx="8" fill="rgba(255,255,255,0.22)" stroke="rgba(255,255,255,0.4)" />

          {/* Lid — lifts and tilts while opening */}
          <motion.g
            initial={{ y: 0, rotate: 0 }}
            animate={
              reducedMotion
                ? { y: opening ? -10 : 0 }
                : opening
                  ? { y: -64, rotate: -16, x: 10 }
                  : { y: 0, rotate: 0, x: 0 }
            }
            transition={{ duration: 0.7, delay: opening ? 0.4 : 0, ease: 'backOut' }}
            style={{ transformOrigin: '150px 92px' }}
          >
            <rect x="72" y="74" width="156" height="26" rx="13" fill="url(#lid)" stroke="rgba(0,0,0,0.12)" />
            <rect x="78" y="70" width="144" height="12" rx="6" fill={legendary ? '#ffe9a8' : '#e7d6b6'} />
            <circle cx="150" cy="68" r="7" fill={legendary ? '#fff6e6' : '#caa978'} />
          </motion.g>
        </svg>
      </motion.div>

      {/* Sparkles puffing from the mouth on open */}
      {!reducedMotion && opening && (
        <div className="pointer-events-none absolute left-1/2 top-[16%] -translate-x-1/2" aria-hidden="true">
          {Array.from({ length: 12 }).map((_, i) => {
            const angle = (i / 12) * Math.PI * 2;
            return (
              <motion.span
                key={i}
                className="absolute block h-1.5 w-1.5 rounded-full"
                style={{ background: i % 2 ? '#fff6e6' : '#ffd79a' }}
                initial={{ opacity: 0, x: 0, y: 0, scale: 0.5 }}
                animate={{
                  opacity: [0, 1, 0],
                  x: Math.cos(angle) * (40 + Math.random() * 40),
                  y: Math.sin(angle) * (40 + Math.random() * 40) - 20,
                  scale: [0.5, 1.2, 0.4],
                }}
                transition={{ duration: 0.9, delay: 0.45 + Math.random() * 0.2, ease: 'easeOut' }}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}
