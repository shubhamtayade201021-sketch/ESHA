import { forwardRef } from 'react';
import type { ButtonHTMLAttributes, ReactNode } from 'react';

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  active?: boolean;
  children: ReactNode;
}

/** A round, frosted icon button with an accessible label. */
export const IconButton = forwardRef<HTMLButtonElement, Props>(function IconButton(
  { label, active = false, children, className = '', ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      type="button"
      aria-label={label}
      aria-pressed={active}
      title={label}
      className={[
        'grid h-11 w-11 place-items-center rounded-full text-lg transition',
        'glass hover:bg-night-600/70 active:scale-95',
        active ? 'ring-2 ring-lilac-soft/70 text-glow-200' : 'text-ink/90',
        className,
      ].join(' ')}
      {...rest}
    >
      <span aria-hidden="true">{children}</span>
    </button>
  );
});
