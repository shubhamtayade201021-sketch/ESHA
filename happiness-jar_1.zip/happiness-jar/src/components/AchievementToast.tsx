import { useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import type { Achievement } from '../lib/types';

interface Props {
  queue: Achievement[];
  onClear: () => void;
}

/** Shows a stack of "achievement unlocked" toasts, then clears them. */
export function AchievementToast({ queue, onClear }: Props) {
  useEffect(() => {
    if (queue.length === 0) return;
    const t = window.setTimeout(onClear, 4200);
    return () => window.clearTimeout(t);
  }, [queue, onClear]);

  return (
    <div className="pointer-events-none fixed inset-x-0 top-4 z-[60] flex flex-col items-center gap-2 px-4">
      <AnimatePresence>
        {queue.map((a) => (
          <motion.div
            key={a.id}
            className="pointer-events-auto flex items-center gap-3 rounded-2xl px-4 py-3 shadow-glow"
            style={{ background: 'linear-gradient(135deg, rgba(255,246,230,0.96), rgba(255,210,150,0.94))' }}
            initial={{ y: -24, opacity: 0, scale: 0.9 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: -16, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 280, damping: 20 }}
          >
            <span className="text-2xl" aria-hidden="true">
              {a.emoji}
            </span>
            <div>
              <p className="text-xs font-bold uppercase tracking-wide text-[#a8772c]">Achievement unlocked</p>
              <p className="font-display font-semibold text-night-900">{a.title}</p>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
