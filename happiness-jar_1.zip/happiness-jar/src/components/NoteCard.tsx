import { useState } from 'react';
import type { Note, Rarity } from '../lib/types';
import { CATEGORY_META } from '../lib/categories';
import { ACCENTS } from '../lib/accents';

interface Props {
  note: Note;
  rarity?: Rarity;
  favorite?: boolean;
  onToggleFavorite?: (id: string) => void;
  /** Compact variant used inside the collection grid. */
  compact?: boolean;
}

const RARITY_LABEL: Record<Rarity, string> = {
  common: '',
  uncommon: 'Uncommon',
  rare: 'Rare ✦',
  legendary: 'Legendary 👑',
};

/** A single surprise rendered on a warm slip of paper. */
export function NoteCard({ note, rarity = 'common', favorite, onToggleFavorite, compact = false }: Props) {
  const meta = CATEGORY_META[note.category];
  const accent = ACCENTS[meta.accent];
  const [revealed, setRevealed] = useState<string | null>(null);

  return (
    <article
      className={[
        'paper relative rounded-2xl shadow-soft',
        compact ? 'p-4' : 'p-6 sm:p-7',
      ].join(' ')}
      style={{ borderTop: `4px solid ${accent.hex}` }}
    >
      <div className="flex items-start justify-between gap-3">
        <span
          className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold"
          style={{ background: accent.soft, color: accent.text }}
        >
          <span aria-hidden="true">{meta.emoji}</span>
          {meta.label}
        </span>
        {onToggleFavorite && (
          <button
            type="button"
            onClick={() => onToggleFavorite(note.id)}
            aria-label={favorite ? 'Remove from favourites' : 'Add to favourites'}
            aria-pressed={favorite}
            className="text-xl leading-none transition hover:scale-110"
            title={favorite ? 'Favourited' : 'Favourite'}
          >
            <span aria-hidden="true">{favorite ? '💖' : '🤍'}</span>
          </button>
        )}
      </div>

      <div className={compact ? 'mt-3' : 'mt-4'}>
        <div className="flex items-center gap-2">
          <span className={compact ? 'text-2xl' : 'text-3xl'} aria-hidden="true">
            {note.emoji}
          </span>
          <h3 className={['font-display font-semibold', compact ? 'text-base' : 'text-xl'].join(' ')}>
            {note.title}
          </h3>
        </div>
        <p className={['mt-2 leading-relaxed text-[#3a2e44]', compact ? 'text-sm' : 'text-[1.05rem]'].join(' ')}>
          {note.message}
        </p>
      </div>

      {/* Optional photo (kept graceful if the file is missing) */}
      {note.image && (
        <img
          src={`./${note.image}`}
          alt={note.title}
          loading="lazy"
          className="mt-4 max-h-60 w-full rounded-xl object-cover"
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).style.display = 'none';
          }}
        />
      )}

      {/* Optional audio clip */}
      {note.audio && (
        <audio controls preload="none" className="mt-4 w-full">
          <source src={`./${note.audio}`} />
        </audio>
      )}

      {/* Optional inline button (coupon redeem / external link) */}
      {note.button && (
        <div className="mt-4">
          {note.button.href ? (
            <a
              href={note.button.href}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-bold text-night-900"
              style={{ background: accent.hex }}
            >
              {note.button.label} ↗
            </a>
          ) : (
            <button
              type="button"
              onClick={() => setRevealed(note.button?.reveal ?? '💛')}
              className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-bold text-night-900"
              style={{ background: accent.hex }}
            >
              {note.button.label}
            </button>
          )}
          {revealed && <p className="mt-2 text-sm font-semibold text-[#6b4a2c]">{revealed}</p>}
        </div>
      )}

      {RARITY_LABEL[rarity] && (
        <span
          className="absolute -right-2 -top-2 rotate-6 rounded-full bg-glow-500 px-2.5 py-1 text-xs font-extrabold text-night-900 shadow"
        >
          {RARITY_LABEL[rarity]}
        </span>
      )}
    </article>
  );
}
