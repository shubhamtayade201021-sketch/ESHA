import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import type { Mood } from '../lib/types';
import { MOOD_META, MOOD_ORDER } from '../lib/categories';

interface Props {
  mood: Mood | null;
  onSelect: (mood: Mood | null) => void;
  reducedMotion: boolean;
}

/** A gentle "how are you feeling?" check-in anchored to the bottom of the scene. */
export function MoodSelector({ mood, onSelect, reducedMotion }: Props) {
  const [open, setOpen] = useState(false);
  const current = mood ? MOOD_META[mood] : null;

  return (
    <div className="relative flex flex-col items-center">
      <AnimatePresence>
        {open && (
          <motion.div
            role="group"
            aria-label="Choose a mood"
            className="glass absolute bottom-14 mb-2 flex max-w-[92vw] flex-wrap justify-center gap-2 rounded-2xl p-3 shadow-soft"
            initial={{ y: 12, opacity: 0, scale: 0.96 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 8, opacity: 0, scale: 0.96 }}
            transition={reducedMotion ? { duration: 0 } : { type: 'spring', stiffness: 300, damping: 24 }}
          >
            {MOOD_ORDER.map((m) => {
              const meta = MOOD_META[m];
              const active = mood === m;
              return (
                <button
                  key={m}
                  type="button"
                  onClick={() => {
                    onSelect(active ? null : m);
                    setOpen(false);
                  }}
                  aria-pressed={active}
                  className={[
                    'flex items-center gap-1.5 rounded-full px-3 py-2 text-sm font-semibold transition',
                    active ? 'bg-lilac-soft/30 ring-2 ring-lilac-soft text-ink' : 'hover:bg-night-600/70 text-ink/90',
                  ].join(' ')}
                >
                  <span aria-hidden="true">{meta.emoji}</span>
                  {meta.label}
                </button>
              );
            })}
            {mood && (
              <button
                type="button"
                onClick={() => {
                  onSelect(null);
                  setOpen(false);
                }}
                className="rounded-full px-3 py-2 text-sm font-semibold text-muted hover:text-ink"
              >
                Clear
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="glass flex items-center gap-2 rounded-full px-5 py-3 font-semibold text-ink shadow-soft transition hover:bg-night-600/70"
      >
        {current ? (
          <>
            <span aria-hidden="true">{current.emoji}</span>
            Feeling {current.label.toLowerCase()}
          </>
        ) : (
          <>
            <span aria-hidden="true">🫶</span>
            How are you feeling?
          </>
        )}
      </button>
    </div>
  );
}
