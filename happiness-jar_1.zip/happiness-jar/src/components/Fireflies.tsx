import { useMemo } from 'react';
import { motion } from 'framer-motion';

interface Props {
  reducedMotion: boolean;
  count?: number;
}

interface Fly {
  id: number;
  left: number;
  top: number;
  size: number;
  dur: number;
  delay: number;
  dx: number;
  dy: number;
}

/** A handful of warm fireflies drifting in lazy loops. */
export function Fireflies({ reducedMotion, count = 14 }: Props) {
  const flies = useMemo<Fly[]>(
    () =>
      Array.from({ length: count }, (_, id) => ({
        id,
        left: Math.random() * 100,
        top: Math.random() * 100,
        size: Math.random() * 5 + 3,
        dur: Math.random() * 8 + 7,
        delay: Math.random() * 6,
        dx: (Math.random() - 0.5) * 70,
        dy: (Math.random() - 0.5) * 70,
      })),
    [count],
  );

  if (reducedMotion) {
    // Keep a few static glints so the scene still feels alive.
    return (
      <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-0">
        {flies.slice(0, 6).map((f) => (
          <span
            key={f.id}
            className="absolute rounded-full bg-glow-200"
            style={{
              left: `${f.left}%`,
              top: `${f.top}%`,
              width: f.size,
              height: f.size,
              opacity: 0.5,
              boxShadow: '0 0 12px 4px rgba(255,210,150,0.45)',
            }}
          />
        ))}
      </div>
    );
  }

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-0">
      {flies.map((f) => (
        <motion.span
          key={f.id}
          className="absolute rounded-full bg-glow-200"
          style={{
            left: `${f.left}%`,
            top: `${f.top}%`,
            width: f.size,
            height: f.size,
            boxShadow: '0 0 14px 5px rgba(255,210,150,0.5)',
          }}
          animate={{
            x: [0, f.dx, -f.dx * 0.6, 0],
            y: [0, f.dy, f.dy * 0.4, 0],
            opacity: [0.15, 0.85, 0.4, 0.15],
            scale: [0.8, 1.15, 0.9, 0.8],
          }}
          transition={{
            duration: f.dur,
            delay: f.delay,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      ))}
    </div>
  );
}
