import { useCallback, useState } from 'react';
import { useJarApp } from './hooks/useJarApp';
import { useAudio } from './hooks/useAudio';
import { useSystemReducedMotion } from './hooks/useReducedMotion';
import { RECIPIENT_NAME, MOOD_META } from './lib/categories';
import { celebrate } from './lib/confetti';
import type { EasterEgg } from './lib/rarity';

import { StarsBackground } from './components/StarsBackground';
import { Fireflies } from './components/Fireflies';
import { Jar } from './components/Jar';
import { OpenButton } from './components/OpenButton';
import { NoteReveal } from './components/NoteReveal';
import { EffectsLayer } from './components/EffectsLayer';
import { AchievementToast } from './components/AchievementToast';
import { MoodSelector } from './components/MoodSelector';
import { TopBar } from './components/TopBar';
import { CollectionPanel } from './components/CollectionPanel';
import { AchievementsPanel } from './components/AchievementsPanel';
import { SettingsPanel } from './components/SettingsPanel';

type PanelId = 'collection' | 'achievements' | 'settings' | null;

export default function App() {
  const app = useJarApp();
  const { sfx } = useAudio(app.prefs);
  const systemReducedMotion = useSystemReducedMotion();

  const {
    prefs,
    reducedMotion,
    mood,
    setMood,
    saved,
    stats,
    open,
    toggleFavorite,
    resolveNote,
    achievements,
    unlockedIds,
    newlyUnlocked,
    acknowledgeAchievements,
    toggleMusic,
    toggleSfx,
    toggleReducedMotion,
  } = app;

  const soothing = mood ? MOOD_META[mood].soothing : false;

  // ── Transient UI state ──────────────────────────────────────────────────--
  const [panel, setPanel] = useState<PanelId>(null);
  const [opening, setOpening] = useState(false);
  const [reveal, setReveal] = useState<ReturnType<typeof open> | null>(null);
  const [revealOpen, setRevealOpen] = useState(false);
  const [activeEgg, setActiveEgg] = useState<EasterEgg>(null);
  const [legendaryActive, setLegendaryActive] = useState(false);

  const present = useCallback(
    (result: NonNullable<typeof reveal>) => {
      setReveal(result);
      setRevealOpen(true);
      if (result.confetti) celebrate(result.rarity);
      if (result.easterEgg) {
        setActiveEgg(result.easterEgg);
        if (result.easterEgg === 'legendary') setLegendaryActive(true);
      }
      window.setTimeout(() => sfx(result.rarity === 'legendary' ? 'achievement' : 'sparkle'), 140);
    },
    [sfx],
  );

  const handleOpen = useCallback(() => {
    if (opening) return;
    const result = open();
    sfx('open');

    // "Open another" (modal already up) or reduced motion: reveal immediately.
    if (revealOpen || reducedMotion) {
      present(result);
      return;
    }

    // Otherwise play the jar's shake → lid-lift before revealing.
    setOpening(true);
    if (result.easterEgg === 'legendary') setLegendaryActive(true);
    window.setTimeout(() => {
      setOpening(false);
      present(result);
    }, 820);
  }, [opening, revealOpen, reducedMotion, open, sfx, present]);

  const handleEggDone = useCallback(() => {
    setActiveEgg(null);
    setLegendaryActive(false);
  }, []);

  const revealFavorite = reveal
    ? saved.find((s) => s.noteId === reveal.note.id)?.favorite ?? false
    : false;

  return (
    <div
      className={[
        'relative min-h-[100dvh] w-full overflow-hidden table-glow',
        reducedMotion ? 'reduce-motion' : '',
      ].join(' ')}
    >
      <StarsBackground reducedMotion={reducedMotion} legendary={legendaryActive} />
      <Fireflies reducedMotion={reducedMotion} count={soothing ? 8 : 14} />

      <TopBar
        musicOn={prefs.musicOn}
        onToggleMusic={toggleMusic}
        onOpenCollection={() => setPanel('collection')}
        onOpenAchievements={() => setPanel('achievements')}
        onOpenSettings={() => setPanel('settings')}
        collectionCount={saved.length}
        achievementsUnlocked={unlockedIds.size}
        achievementsTotal={achievements.length}
      />

      <AchievementToast queue={newlyUnlocked} onClear={acknowledgeAchievements} />

      <main className="relative z-10 mx-auto flex min-h-[100dvh] max-w-2xl flex-col items-center justify-between px-4 py-6">
        <header className="pt-12 text-center sm:pt-14">
          <p className="font-body text-sm uppercase tracking-[0.3em] text-glow-200/80">
            For {RECIPIENT_NAME}
          </p>
          <h1 className="text-balance mt-2 font-display text-4xl font-bold leading-tight text-ink sm:text-5xl">
            Your Jar of Happiness
          </h1>
          <p className="text-balance mx-auto mt-3 max-w-md font-body text-base text-muted sm:text-lg">
            {soothing
              ? 'Take your time. There’s no rush here — just a little softness whenever you need it. 🤍'
              : 'Every tap hides a tiny surprise from me. ❤️'}
          </p>
        </header>

        <section className="flex flex-col items-center gap-8 py-6">
          <button
            type="button"
            onClick={handleOpen}
            aria-label="Open the jar"
            disabled={opening}
            className="cursor-pointer rounded-full focus:outline-none disabled:cursor-default"
          >
            <Jar
              opening={opening}
              reducedMotion={reducedMotion}
              legendary={legendaryActive}
              soothing={soothing}
            />
          </button>

          <div className="flex flex-col items-center gap-3">
            <OpenButton onClick={handleOpen} disabled={opening} reducedMotion={reducedMotion} />
            <p className="h-5 font-body text-sm text-muted">
              {stats.totalOpens > 0
                ? `${stats.totalOpens} ${stats.totalOpens === 1 ? 'surprise' : 'surprises'} opened so far ✨`
                : 'Tap the jar or the button to begin ✨'}
            </p>
          </div>
        </section>

        <footer className="flex w-full flex-col items-center gap-2 pb-3">
          <MoodSelector mood={mood} onSelect={setMood} reducedMotion={reducedMotion} />
        </footer>
      </main>

      {/* The surprise reveal */}
      <NoteReveal
        result={reveal}
        open={revealOpen}
        onClose={() => setRevealOpen(false)}
        onAnother={handleOpen}
        favorite={revealFavorite}
        onToggleFavorite={toggleFavorite}
        reducedMotion={reducedMotion}
      />

      {/* Panels */}
      <CollectionPanel
        open={panel === 'collection'}
        onClose={() => setPanel(null)}
        saved={saved}
        resolveNote={resolveNote}
        onToggleFavorite={toggleFavorite}
      />
      <AchievementsPanel
        open={panel === 'achievements'}
        onClose={() => setPanel(null)}
        achievements={achievements}
        unlockedIds={unlockedIds}
        stats={stats}
      />
      <SettingsPanel
        open={panel === 'settings'}
        onClose={() => setPanel(null)}
        prefs={prefs}
        systemReducedMotion={systemReducedMotion}
        onToggleMusic={toggleMusic}
        onToggleSfx={toggleSfx}
        onToggleReducedMotion={toggleReducedMotion}
      />

      {/* Rare easter-egg effects render above everything */}
      <EffectsLayer egg={activeEgg} onDone={handleEggDone} reducedMotion={reducedMotion} />
    </div>
  );
}
