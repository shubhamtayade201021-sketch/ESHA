/* The Virtual Jar of Happiness — tiny offline service worker.
 *
 * Strategy: cache the app shell on install, then serve cached assets when the
 * network is unavailable (cache-first for same-origin GET requests, with a
 * network fallback that updates the cache). Honest and simple — no magic.
 *
 * Because the app is served from a relative base, we cache lazily as requests
 * succeed rather than hard-coding a precise file list (Vite hashes filenames).
 */

const CACHE = 'happiness-jar-v1';
const APP_SHELL = ['./', './index.html', './favicon.svg', './404.html'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => cache.addAll(APP_SHELL))
      .catch(() => undefined)
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) {
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      const network = fetch(request)
        .then((response) => {
          if (response && response.status === 200 && response.type === 'basic') {
            const copy = response.clone();
            caches.open(CACHE).then((cache) => cache.put(request, copy));
          }
          return response;
        })
        .catch(() => cached);

      // Cache-first, but kick off a background refresh.
      return cached || network;
    }),
  );
});
