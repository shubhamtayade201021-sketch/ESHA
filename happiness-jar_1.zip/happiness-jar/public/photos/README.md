# Photos (optional)

Drop image files here (e.g. `beach-day.jpg`) and reference them from a note's
`image` field in the content packs, like `image: 'photos/beach-day.jpg'`.

Supported: jpg, png, webp, gif, svg. Keep them reasonably small (< 500 KB each)
so the jar loads fast and works offline. If a referenced image is missing, the
note still shows gracefully — the picture is just hidden.
