# Audio (optional)

Drop short audio clips here (e.g. `our-song.mp3`) and reference them from a
note's `audio` field, like `audio: 'audio/our-song.mp3'`.

Only add music you have the right to use. The app itself ships with NO
copyrighted audio — its ambient sound and effects are generated live in the
browser with the Web Audio API, so it stays free and works offline.
