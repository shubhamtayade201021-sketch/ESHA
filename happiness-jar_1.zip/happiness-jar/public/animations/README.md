# Animations (optional)

This folder is a placeholder for any custom animation assets (e.g. Lottie JSON)
you might add later. The app does not require any files here — all of its
animations are built with Framer Motion, SVG, and Canvas, so it runs fully
offline with nothing to download.
