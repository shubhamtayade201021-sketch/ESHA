/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Deep midnight night sky (not pure black — a dreamy plum-indigo)
        night: {
          900: '#0c0817',
          800: '#120c22',
          700: '#191130',
          600: '#221842',
        },
        // Warm light that pours out of the jar
        glow: {
          50: '#fff6e6',
          200: '#ffe2b0',
          400: '#ffc878',
          500: '#ffba6b',
          600: '#f7a64a',
        },
        // Pastel category accents
        rose: { soft: '#ffb3d1' },
        lilac: { soft: '#c5b3ff' },
        mint: { soft: '#a8e6cf' },
        peach: { soft: '#ffd3b6' },
        sky: { soft: '#a8d8ff' },
        wood: '#3a2a22',
        ink: '#f4eef7',
        muted: '#b9a9d6',
      },
      fontFamily: {
        display: ['Fraunces', 'Georgia', 'serif'],
        body: ['Nunito', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        glow: '0 0 60px -10px rgba(255,186,107,0.55)',
        'glow-lg': '0 0 120px -20px rgba(255,186,107,0.6)',
        soft: '0 10px 40px -12px rgba(0,0,0,0.55)',
      },
      keyframes: {
        breathe: {
          '0%,100%': { transform: 'translateY(0) scale(1)' },
          '50%': { transform: 'translateY(-8px) scale(1.012)' },
        },
        shimmer: {
          '0%,100%': { opacity: '0.5' },
          '50%': { opacity: '1' },
        },
        'float-slow': {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-14px)' },
        },
        'pulse-glow': {
          '0%,100%': { boxShadow: '0 0 40px -8px rgba(255,186,107,0.5)' },
          '50%': { boxShadow: '0 0 80px -6px rgba(255,186,107,0.85)' },
        },
        twinkle: {
          '0%,100%': { opacity: '0.2', transform: 'scale(0.8)' },
          '50%': { opacity: '1', transform: 'scale(1.1)' },
        },
      },
      animation: {
        breathe: 'breathe 6s ease-in-out infinite',
        shimmer: 'shimmer 3s ease-in-out infinite',
        'float-slow': 'float-slow 7s ease-in-out infinite',
        'pulse-glow': 'pulse-glow 3.2s ease-in-out infinite',
        twinkle: 'twinkle 4s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
