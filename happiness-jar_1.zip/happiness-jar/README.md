# 🫙 The Virtual Jar of Happiness

A cozy, magical dark-mode web app where every tap opens a glass jar and reveals a
tiny surprise — a reason you're loved, a compliment, a silly joke, a memory, a
date idea, a redeemable coupon, and more. Built as a heartfelt gift for **Esha**.

There are **504 handcrafted notes** across **18 categories**, gentle ambient
sound, confetti, rare easter eggs, a saveable collection, achievements, and a
soothing "comfort mode" for harder days. It runs entirely in the browser, works
**offline**, and is **100% free to host** on GitHub Pages.

---

## ✨ Features

- **Tap the jar** to open a random surprise, with a shake → lid-lift → golden-beam reveal.
- **18 categories**: love reasons, compliments, jokes, cute animals, songs, movies, memories, love letters, challenges, self-care, ADHD-friendly nudges, date ideas, bedtime notes, good-morning notes, coupons, kisses, hugs, and surprises.
- **Mood selector** — pick how you're feeling and the jar gently weights what it gives you (soothing notes when you're anxious, overthinking, sad, or tired).
- **Comfort mode** automatically calms the visuals and sounds when you choose a tender mood.
- **Collection** — favorite any note to keep it; revisit your saved ones anytime.
- **Achievements** — nine little milestones to discover.
- **Rarities & easter eggs** — most notes are common, but keep tapping for uncommon, rare, and legendary moments (plus a few hidden surprise animations 🐾).
- **Ambient sound & effects** generated live with the Web Audio API — no audio files, no copyright issues, fully offline. Toggle on/off anytime.
- **Confetti** on special opens (via `canvas-confetti`).
- **Accessible**: keyboard-friendly, focus rings, ARIA dialogs, and full **reduced-motion** support (respects your system setting and has its own toggle).
- **Offline-ready** via a service worker, and remembers your collection, mood, and settings with LocalStorage.

---

## 🧰 Tech stack

React 18 · Vite 5 · TypeScript (strict) · Tailwind CSS 3 · Framer Motion 11 ·
canvas-confetti · Web Audio API · LocalStorage · GitHub Actions → GitHub Pages.

---

## 🚀 Run it locally

You'll need [Node.js](https://nodejs.org/) 18 or newer.

```bash
npm install      # install dependencies
npm run dev      # start the dev server (Vite prints a localhost URL)
```

Open the URL it prints (usually <http://localhost:5173>) and start tapping.

To build and preview the production version:

```bash
npm run build    # type-check + bundle into dist/
npm run preview  # serve the built dist/ locally
```

---

## 🌐 Deploy it FREE on GitHub Pages

This repo ships with a ready-made GitHub Actions workflow
(`.github/workflows/deploy.yml`) that builds and publishes the site for you.

1. **Create a new GitHub repository** and push this project to it:
   ```bash
   git init
   git add .
   git commit -m "The Virtual Jar of Happiness"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```
2. On GitHub, go to **Settings → Pages**.
3. Under **Build and deployment → Source**, choose **GitHub Actions**.
4. That's it. Every push to `main` rebuilds and redeploys automatically. Your jar
   will be live at `https://<your-username>.github.io/<your-repo>/`.

> The Vite config uses a **relative base path** (`base: './'`), so the app works
> whether it's served from a project subpath (`/your-repo/`) or a root domain —
> no extra configuration needed.

---

## 💝 Make it yours

Everything personal lives in plain, easy-to-edit files. You don't need to touch
the app code to change the words.

### Change the recipient's name

The name appears in two places — update both:

- `src/lib/categories.ts` → `export const RECIPIENT_NAME = 'Esha';`
- `scripts/content-pack-1.mjs` → `export const NAME = 'Esha';`

Then regenerate the notes (see below) so the new name flows through the content.

### Edit, add, or remove notes

All the writing lives in three readable files:

- `scripts/content-pack-1.mjs` — love reasons, compliments, jokes, animals, songs, movies
- `scripts/content-pack-2.mjs` — memories, love letters, challenges, self-care, ADHD nudges, date ideas
- `scripts/content-pack-3.mjs` — bedtime, good-morning, coupons, kisses, hugs, surprises

Each note looks roughly like this:

```js
{ title: 'A tiny truth', message: 'You make ordinary days feel like a celebration.', emoji: '🎉' }
```

After editing any pack, rebuild the notes file:

```bash
npm run generate   # writes src/data/messages.json
npm run count      # (optional) prints how many notes are in each category
```

The generator checks that every note has text and a unique id before saving, so
you'll get a clear error if something's off.

### Add your own photos

Drop image files into `public/photos/` and point a note at one:

```js
{ title: 'That trip', message: 'Remember this day?', emoji: '🏖️', image: 'photos/beach-day.jpg' }
```

If an image is ever missing, the note still shows — the picture just hides.

### Add your own music or sounds

Drop audio into `public/audio/` and reference it from a note's `audio` field.
Please only use audio you have the rights to. (The app's own ambient sound is
generated in-browser, so nothing here is required.)

---

## 🗂️ Project structure

```
happiness-jar/
├─ .github/workflows/deploy.yml   # auto build + deploy to GitHub Pages
├─ index.html                     # app shell + fonts
├─ public/
│  ├─ favicon.svg
│  ├─ sw.js                       # offline service worker
│  ├─ 404.html                    # SPA fallback for Pages
│  ├─ photos/                     # (optional) your images
│  ├─ audio/                      # (optional) your audio
│  └─ animations/                 # (optional) custom animation assets
├─ scripts/
│  ├─ content-pack-1.mjs          # ┐
│  ├─ content-pack-2.mjs          # ├─ all the words live here
│  ├─ content-pack-3.mjs          # ┘
│  └─ generate-messages.mjs       # builds src/data/messages.json
└─ src/
   ├─ App.tsx                     # main composition
   ├─ main.tsx                    # entry + service-worker registration
   ├─ data/messages.json          # generated notes (do not edit by hand)
   ├─ components/                 # jar, reveal, panels, effects, UI
   ├─ hooks/                      # app state, audio, storage, reduced-motion
   ├─ lib/                        # categories, rarity, achievements, audio engine
   └─ styles/index.css            # Tailwind + theme
```

---

## 🛠️ A few intentional design choices

This project was built to be a real, self-contained gift with **no paid services
and no copyright baggage**, so a few things were done deliberately:

- **Animations instead of Lottie files.** Rather than shipping third-party Lottie
  assets, all motion is hand-built with Framer Motion, SVG, and Canvas. Nothing
  to download, nothing to license.
- **Generated sound instead of audio files.** The ambient pad and little sound
  effects are synthesized live with the Web Audio API. That keeps the app free,
  offline-friendly, and free of any music licensing concerns.
- **Emoji and optional media.** Cute-animal, song, and movie notes use expressive
  emoji by default. You can attach your own images/audio (see above) — none are
  bundled to keep things clean and rights-safe.
- **Fonts** are Fraunces (display) and Nunito (body), loaded from Google Fonts.

---

## ♿ Accessibility & offline

- Respects `prefers-reduced-motion` and offers an in-app motion toggle.
- Dialogs use proper roles/labels and are keyboard navigable with visible focus.
- Works offline after the first visit (service worker caches the app shell).
- Your collection, mood, and preferences persist locally on your device.

---

Made with love. 💛
