#!/usr/bin/env node
/**
 * generate-messages.mjs
 * ─────────────────────────────────────────────────────────────────────────────
 * Assembles src/data/messages.json from the three hand-written content packs.
 *
 *   npm run generate   → (re)writes src/data/messages.json
 *   npm run count      → prints totals + per-category breakdown (writes nothing)
 *
 * To make the jar yours:
 *   1. Edit any line in scripts/content-pack-{1,2,3}.mjs (and change NAME there).
 *   2. Optionally attach media to a note:
 *        image: 'photos/us.jpg'        // drop the file in public/photos/
 *        audio: 'audio/our-song.mp3'   // drop the file in public/audio/
 *        btn:   { label: 'Play', href: 'https://...' }
 *   3. Run `npm run generate`.
 *
 * Nothing here is auto-generated filler — every note was written by hand.
 */

import { writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  loveReasons,
  compliments,
  jokes,
  animals,
  songs,
  movies,
} from './content-pack-1.mjs';
import {
  memories,
  loveLetters,
  challenges,
  selfCare,
  adhd,
  dateIdeas,
} from './content-pack-2.mjs';
import {
  bedtime,
  goodMorning,
  coupons,
  kisses,
  hugs,
  surprises,
} from './content-pack-3.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const OUT = resolve(__dirname, '../src/data/messages.json');

/** Per-category fallback emoji when an entry doesn't set its own. */
const DEFAULT_EMOJI = {
  'love-reason': '❤️',
  compliment: '🥹',
  joke: '😂',
  animal: '🐾',
  song: '🎵',
  movie: '🎬',
  memory: '📸',
  'love-letter': '💌',
  challenge: '✨',
  'self-care': '🌸',
  adhd: '🧠',
  'date-idea': '🎁',
  bedtime: '🌙',
  'good-morning': '🌞',
  coupon: '🎟️',
  kiss: '💋',
  hug: '🤗',
  surprise: '🎲',
};

/**
 * Turns a raw entry (string or object) into a fully-formed Note.
 *   { t: title, m: message, e: emoji, btn: button, r: rarity }
 */
function toNote(category, idx, entry) {
  const o = typeof entry === 'string' ? { m: entry } : entry;
  if (!o || typeof o.m !== 'string' || o.m.trim() === '') {
    throw new Error(`Empty message in "${category}" at index ${idx}`);
  }
  return {
    id: `${category}-${String(idx + 1).padStart(3, '0')}`,
    category,
    title: o.t ?? '',
    message: o.m,
    emoji: o.e ?? DEFAULT_EMOJI[category],
    ...(o.image ? { image: o.image } : {}),
    ...(o.audio ? { audio: o.audio } : {}),
    ...(o.animation ? { animation: o.animation } : {}),
    ...(o.btn ? { button: o.btn } : {}),
    ...(o.r ? { rarity: o.r } : {}),
  };
}

// Category id → raw entries. Order here is the canonical category order.
const SOURCES = {
  'love-reason': loveReasons,
  compliment: compliments,
  joke: jokes,
  animal: animals,
  song: songs,
  movie: movies,
  memory: memories,
  'love-letter': loveLetters,
  challenge: challenges,
  'self-care': selfCare,
  adhd: adhd,
  'date-idea': dateIdeas,
  bedtime: bedtime,
  'good-morning': goodMorning,
  coupon: coupons,
  kiss: kisses,
  hug: hugs,
  surprise: surprises,
};

// Build every note and validate as we go.
const notes = [];
const seenIds = new Set();
const breakdown = {};

for (const [category, entries] of Object.entries(SOURCES)) {
  if (!Array.isArray(entries)) {
    throw new Error(`Category "${category}" has no entries array.`);
  }
  breakdown[category] = entries.length;
  entries.forEach((entry, idx) => {
    const n = toNote(category, idx, entry);
    if (seenIds.has(n.id)) throw new Error(`Duplicate id ${n.id}`);
    seenIds.add(n.id);
    notes.push(n);
  });
}

const total = notes.length;
const countOnly = process.argv.includes('--count');

// Pretty per-category report.
const report = Object.entries(breakdown)
  .map(([cat, n]) => `  ${cat.padEnd(14)} ${String(n).padStart(3)}`)
  .join('\n');

if (countOnly) {
  console.log(`\nThe Virtual Jar of Happiness — message count\n`);
  console.log(report);
  console.log(`  ${'─'.repeat(18)}`);
  console.log(`  ${'TOTAL'.padEnd(14)} ${String(total).padStart(3)}\n`);
  console.log(`Categories: ${Object.keys(SOURCES).length}`);
  process.exit(0);
}

// Write the JSON the app imports.
mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, JSON.stringify(notes, null, 2) + '\n', 'utf8');

console.log(`\n✨ Wrote ${total} notes across ${Object.keys(SOURCES).length} categories to:`);
console.log(`   ${OUT}\n`);
console.log(report);
console.log(`  ${'─'.repeat(18)}`);
console.log(`  ${'TOTAL'.padEnd(14)} ${String(total).padStart(3)}\n`);
